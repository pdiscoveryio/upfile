#!/bin/bash

# Function to block addresses containing "k6.io" in the request and "{ "-" "-"}"
block_ips() {
    # Extract addresses from log entries containing "k6.io" or "{ "-" "-"}" or |"-" 408 [0-9]+ "-" "-" in the request
    echo "Checking for IPs to block..."
    grep -E 'k6\.io|{ "-" "-"}' /etc/httpd/logs/access_log | awk '{print $1}' | sort | uniq | \
    while read ip; do
        # Check if the address is already blocked
        if ! sudo iptables -L INPUT -v -n | grep -q "$ip"; then
            # Block the address using iptables
            sudo iptables -A INPUT -s "$ip" -j DROP
            echo "Blocked IP: $ip"
        else
            echo "$is already blocked. Skipping..."
        fi
    done
    echo "blocking check completed."
}

# Main loop with 5-second interval
while true; do
    echo "Starting blocking check..."
    block_ips
    echo "Waiting for 5 seconds before next check..."
#    sudo service apache2 restart
    sleep 10
done




