#!/bin/bash

# Define Google IP ranges including local subnet
iplisttoexclude=(
    "64\.18\."
    "64\.233\."
    "66\.102\."
    "66\.249\."
    "72\.14\."
    "74\.125\."
    "108\.177\."
    "173\.194\."
    "207\.126\."
    "209\.85\."
    "216\.58\."
    "216\.239\."
    "64\.68\."
    "66\.249\."
    "64\.233\."
    "108\.177\."
	"119\.148\."
    "43\.231\.79\.19[2-9]"  # Add your IP range here
    "43\.231\.79\.2[0-4][0-9]"
    "43\.231\.79\.25[0-5]"
)

# List to store blocked IP addresses
blocked_ips=()

# Function to check if IP is in the exclusion list
is_excluded_ip() {
    local ip=$1
    for range in "${iplisttoexclude[@]}"; do
        if echo "$ip" | grep -qE "^$range"; then
            return 0
        fi
    done
    return 1
}

# Function to convert IP address to CIDR notation
ip_to_cidr() {
    local ip=$1
    echo "$ip/32"
}

# Function to process log entries
process_log_entries() {
    tail -1000 /etc/httpd/logs/access_log | awk '{print $1}' | sort | uniq -c | sort -nr | \
    while read count ip; do
        if [ "$count" -gt 70 ] && ! is_excluded_ip "$ip" && ! [[ " ${blocked_ips[@]} " =~ " $ip " ]]; then
            echo "Request count for IP $ip exceeds 100 ($count requests) and is not in the exclusion list. Blocking IP..."
            cidr_ip=$(ip_to_cidr "$ip")
            echo "Blocking CIDR IP: $cidr_ip"
            # Add iptables rule to block IP here
            sudo iptables -A INPUT -s "$cidr_ip" -j DROP
            # Add IP to blocked list
            blocked_ips+=("$ip")
        fi
    done
}

# Main loop with 5-second interval
while true; do
    process_log_entries
    sleep 5
done

